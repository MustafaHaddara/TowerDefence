

#include "MMPhysEntity.h"
#include "MMGame.h"


using namespace  MMGame;




PhysEntity::PhysEntity():RigidBodyController(kPhysEnity)
{
    
}


PhysEntity::~PhysEntity()
{
    
}
